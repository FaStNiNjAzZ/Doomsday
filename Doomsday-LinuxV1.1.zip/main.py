import time
import random
import subprocess as sp


print("""Select the country you want to be:
>USSR
>USA
""")
global cs
cs = input('>')

#Game
def usa():
  check = True
  usap = input('>')
  a = ["Texas", "New Mexico", "California", "Nevada", "Washington", "Colorado", "Missouri", "Florida", "South Carolina", "Kentucky", "Tennesse", "Ohio"]
  b = ["Moscow", "Vologda", "Smolensk", "Tula", "Kursk", "Penza", "Tambov", "Murmansk", "Oufa", "Yekaterinburg", "Serov", "Lesosibirsk"]
  computerattack = random.randint(0,len(b)-1)
  computerattack1 = b[computerattack]
  while check == True:
    sp.call('clear',shell=True)
    computer = random.randint(0,len(a)-1)
    #print(computer)
    computercheck = a[computer]
    #print(a)
    if computercheck == (usap):
      print('You lose!')
      check = False
      input("[Press any key to continue]")
      agameover()
    print ("USSR has nuked", computercheck)
    time.sleep(1)
    if check == True:
      print('')
      print("Cities remaining:")
      print ("\n".join(map(str, b)))
      print('')
      print("Input the city you want to attack")
      attack = input('>')
      if attack == computerattack1:
        print("You win!")
        check = False
        input("[Press any key to continue]")
        agameover()
      b.remove(attack)
    del a[computer]
    time.sleep(1)


def ussr():
  check = True
  usap = input('>')
  b = ["Texas", "New Mexico", "California", "Nevada", "Washington", "Colorado", "Missouri", "Florida", "South Carolina", "Kentucky", "Tennesse", "Ohio"]
  a = ["Moscow", "Vologda", "Smolensk", "Tula", "Kursk", "Penza", "Tambov", "Murmansk", "Oufa", "Yekaterinburg", "Serov", "Lesosibirsk"]
  computerattack = random.randint(0,len(b)-1)
  computerattack1 = b[computerattack]
  while check == True:
    sp.call('clear',shell=True)
    computer = random.randint(0,len(a)-1)
    #print(computer)
    computercheck = a[computer]
    #print(a)
    if computercheck == (usap):
      print('You lose!')
      check = False
      input("[Press any key to continue]")
      agameover()
    print ("USA has nuked", computercheck)
    time.sleep(1)
    if check == True:
      print('')
      print("States remaining:")
      print ("\n".join(map(str, b)))
      print('')
      print ("Input the city you want to attack")
      attack = input('>')
      if attack == computerattack1:
        print("You win!")
        check = False
        input("[Press any key to continue]")
        agameover()
      del a[computer]
      b.remove(attack)
      time.sleep(1)


#Animation Scripts
def agameover():
  sp.call('clear',shell=True)
  print("""
           \/

           
           
           




                  ^
     _______     ^^^
    |xxxxxxx|  _^^^^^_
    |xxxxxxx| | [][]  |
 ______xxxxx| |[][][] |
|++++++|xxxx| | [][][]|      
|++++++|xxxx| |[][][] |
|++++++|_________ [][]|
|++++++|=|=|=|=|=| [] |
|++++++|=|=|=|=|=|[][]|
|++HH++|  _HHHH__|____| 
____________________________________________________
                                          
 _____ 
|   __| 
|  |  |
|_____| 
""")
  time.sleep(0.7)
  sp.call('clear',shell=True)
  print("""
          \  /
           \/

           
           




                  ^
     _______     ^^^
    |xxxxxxx|  _^^^^^_
    |xxxxxxx| | [][]  |
 ______xxxxx| |[][][] |
|++++++|xxxx| | [][][]|      
|++++++|xxxx| |[][][] |
|++++++|_________ [][]|
|++++++|=|=|=|=|=| [] |
|++++++|=|=|=|=|=|[][]|
|++HH++|  _HHHH__|____|  
____________________________________________________
                                             
 _____                  
|   __| ___  
|  |  || .'|
|_____||__,| 
""")
  time.sleep(0.7)
  sp.call('clear',shell=True)
  print("""
          |  |
          \  /
           \/
           





                  ^
     _______     ^^^
    |xxxxxxx|  _^^^^^_
    |xxxxxxx| | [][]  |
 ______xxxxx| |[][][] |
|++++++|xxxx| | [][][]|      
|++++++|xxxx| |[][][] |
|++++++|_________ [][]|
|++++++|=|=|=|=|=| [] |
|++++++|=|=|=|=|=|[][]|
|++HH++|  _HHHH__|____| 
____________________________________________________
                                              
 _____                   
|   __| ___  _____  
|  |  || .'||     |
|_____||__,||_|_|_| 
""")
  time.sleep(0.7)
  sp.call('clear',shell=True)
  print("""
          |  |
          |  |
          \  /
           \/





                  ^
     _______     ^^^
    |xxxxxxx|  _^^^^^_
    |xxxxxxx| | [][]  |
 ______xxxxx| |[][][] |
|++++++|xxxx| | [][][]|      
|++++++|xxxx| |[][][] |
|++++++|_________ [][]|
|++++++|=|=|=|=|=| [] |
|++++++|=|=|=|=|=|[][]|
|++HH++|  _HHHH__|____|
____________________________________________________
                                                  
 _____                    
|   __| ___  _____  ___  
|  |  || .'||     || -_|
|_____||__,||_|_|_||___| 
""")
  time.sleep(0.7)
  sp.call('clear',shell=True)
  print("""
         \ == /
          |  |
          |  |
          \  /
           \/




                  ^
     _______     ^^^
    |xxxxxxx|  _^^^^^_
    |xxxxxxx| | [][]  |
 ______xxxxx| |[][][] |
|++++++|xxxx| | [][][]|      
|++++++|xxxx| |[][][] |
|++++++|_________ [][]|
|++++++|=|=|=|=|=| [] |
|++++++|=|=|=|=|=|[][]|
|++HH++|  _HHHH__|____|
____________________________________________________
                                                  
 _____                     _____               
|   __| ___  _____  ___   |     |
|  |  || .'||     || -_|  |  |  |
|_____||__,||_|_|_||___|  |_____|
""")
  time.sleep(0.7)
  sp.call('clear',shell=True)
  print("""
         |\**/|
         \ == /
          |  |
          |  |
          \  /
           \/



                  ^
     _______     ^^^
    |xxxxxxx|  _^^^^^_
    |xxxxxxx| | [][]  |
 ______xxxxx| |[][][] |
|++++++|xxxx| | [][][]|      
|++++++|xxxx| |[][][] |
|++++++|_________ [][]|
|++++++|=|=|=|=|=| [] |
|++++++|=|=|=|=|=|[][]|
|++HH++|  _HHHH__|____|
____________________________________________________
                                                 
 _____                     _____                
|   __| ___  _____  ___   |     | _ _  
|  |  || .'||     || -_|  |  |  || | |
|_____||__,||_|_|_||___|  |_____| \_/  
""")
  time.sleep(0.7)
  sp.call('clear',shell=True)
  print("""

         |\**/|
         \ == /
          |  |
          |  |
          \  /
           \/


                  ^
     _______     ^^^
    |xxxxxxx|  _^^^^^_
    |xxxxxxx| | [][]  |
 ______xxxxx| |[][][] |
|++++++|xxxx| | [][][]|      
|++++++|xxxx| |[][][] |
|++++++|_________ [][]|
|++++++|=|=|=|=|=| [] |
|++++++|=|=|=|=|=|[][]|
|++HH++|  _HHHH__|____|
____________________________________________________
                                                 
 _____                     _____                
|   __| ___  _____  ___   |     | _ _  ___  
|  |  || .'||     || -_|  |  |  || | || -_|
|_____||__,||_|_|_||___|  |_____| \_/ |___| 
""")
  time.sleep(0.7)
  sp.call('clear',shell=True)
  print("""


         |\**/|
         \ == /
          |  |
          |  |
          \  /
           \/

                  ^
     _______     ^^^
    |xxxxxxx|  _^^^^^_
    |xxxxxxx| | [][]  |
 ______xxxxx| |[][][] |
|++++++|xxxx| | [][][]|      
|++++++|xxxx| |[][][] |
|++++++|_________ [][]|
|++++++|=|=|=|=|=| [] |
|++++++|=|=|=|=|=|[][]|
|++HH++|  _HHHH__|____|
____________________________________________________
                                                  
 _____                     _____                
|   __| ___  _____  ___   |     | _ _  ___  ___ 
|  |  || .'||     || -_|  |  |  || | || -_||  _|
|_____||__,||_|_|_||___|  |_____| \_/ |___||_|  
""")
  time.sleep(0.7)
  sp.call('clear',shell=True)
  print("""



         |\**/|
         \ == /
          |  |
          |  |
          \  /
           \/
                  ^
     _______     ^^^
    |xxxxxxx|  _^^^^^_
    |xxxxxxx| | [][]  |
 ______xxxxx| |[][][] |
|++++++|xxxx| | [][][]|      
|++++++|xxxx| |[][][] |
|++++++|_________ [][]|
|++++++|=|=|=|=|=| [] |
|++++++|=|=|=|=|=|[][]|
|++HH++|  _HHHH__|____|
____________________________________________________
                                                 __ 
 _____                     _____                |  |
|   __| ___  _____  ___   |     | _ _  ___  ___ |  |
|  |  || .'||     || -_|  |  |  || | || -_||  _||__|
|_____||__,||_|_|_||___|  |_____| \_/ |___||_|  |__| 
""")
  time.sleep(0.7)
  sp.call('clear',shell=True)
  print("""
      
    
          
      ############
    ################
   ##################
 ######################
## ################## ##
### ############### ###
 ### ############# ###
      ## ##### ##
         #####
      --#######--
  ---#############---
      --#######--
         #####
         #####     
        #######
    ###############
#######################
____________________________________________________
                                                 __ 
 _____                     _____                |  |
|   __| ___  _____  ___   |     | _ _  ___  ___ |  |
|  |  || .'||     || -_|  |  |  || | || -_||  _||__|
|_____||__,||_|_|_||___|  |_____| \_/ |___||_|  |__|                          
""")
  input('[Press any key to continue]')

#Menu (First)
if cs == 'USA':
  USA = 1
  print('>Texas')
  time.sleep(0.1)
  print('>New Mexico')
  time.sleep(0.1)
  print(">California")
  time.sleep(0.1)
  print(">Nevada")
  time.sleep(0.1)
  print(">Washington")
  time.sleep(0.1)
  print(">Colorado")
  time.sleep(0.1)
  print(">Missouri")
  time.sleep(0.1)
  print(">Florida")
  time.sleep(0.1)
  print(">South Carolina")
  time.sleep(0.1)
  print(">Kentucky")
  time.sleep(0.1)
  print(">Tennesse")
  time.sleep(0.1)
  print(">Ohio")
  print('Input the state you want to be in')
  usa()

elif cs == "USSR":
  USA = 0
  print('>Moscow')
  time.sleep(0.1)
  print('>Vologda')
  time.sleep(0.1)
  print(">Smolensk")
  time.sleep(0.1)
  print(">Tula")
  time.sleep(0.1)
  print(">Kursk")
  time.sleep(0.1)
  print(">Penza")
  time.sleep(0.1)
  print(">Tambov")
  time.sleep(0.1)
  print(">Murmansk")
  time.sleep(0.1)
  print(">Oufa")
  time.sleep(0.1)
  print(">Yekaterinburg")
  time.sleep(0.1)
  print(">Serov")
  time.sleep(0.1)
  print(">Lesosibirsk")
  print("Input the city you want to be in")
  ussr()

else:
  print("Enter a valid option.")

